# Mexico Magico

This is the template for our class
